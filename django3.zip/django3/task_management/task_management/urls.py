# task_management/urls.py

from django.contrib import admin
from django.urls import path, include
from tasks.views import TaskListView  # Импорт представления списка задач
from django.contrib.auth import views as auth_views
from django.views.generic import TemplateView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('tasks/', include('tasks.urls')),  # Маршруты для приложения tasks
    path('users/', include('users.urls')),  # Маршруты для приложения users
    path('', TaskListView.as_view(), name='home'),  # Добавьте этот маршрут для корневого URL
    path('', include('django.contrib.auth.urls')),  # Встроенные маршруты аутентификации
    path('login/', auth_views.LoginView.as_view(template_name='registration/login.html'), name='login'),
     path('', TemplateView.as_view(template_name='index.html'), name='home'),
    
    
]
