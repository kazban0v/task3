# tasks/views.py

from django.shortcuts import render, redirect
from django.views.generic import ListView, CreateView, UpdateView
from django.contrib.auth.models import User, Group
from .models import Task
from .forms import TaskForm
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.urls import reverse_lazy
from django.views.generic import DeleteView


class TaskListView(LoginRequiredMixin, ListView):
    model = Task
    template_name = 'tasks/task_list.html'
    login_url = 'login'

    def get_queryset(self):
        queryset = super().get_queryset()
        
        # Фильтр "Назначенные мне"
        if self.request.GET.get('assigned_to_me'):
            queryset = queryset.filter(assigned_to=self.request.user)

        # Фильтр "Задачи Project Manager"
        if self.request.GET.get('group') == 'Project Manager':
            try:
                group = Group.objects.get(name='Project Manager')
                queryset = queryset.filter(assigned_to__groups=group)
            except Group.DoesNotExist:
                queryset = queryset.none()
        
        return queryset


class TaskCreateView(LoginRequiredMixin, UserPassesTestMixin, CreateView):
    model = Task
    template_name = 'tasks/task_form.html'
    form_class = TaskForm

    def test_func(self):
        # Проверяем, является ли пользователь членом группы "Project Manager"
        return self.request.user.groups.filter(name='Project Manager').exists()

    def form_valid(self, form):
        task = form.save(commit=False)
        task.save()
        return redirect('task-list')


class TaskUpdateView(LoginRequiredMixin, UserPassesTestMixin, UpdateView):
    model = Task
    template_name = 'tasks/task_form.html'
    form_class = TaskForm

    def test_func(self):
        # Проверяем, является ли пользователь членом группы "Project Manager"
        return self.request.user.groups.filter(name='Project Manager').exists()

    def form_valid(self, form):
        task = form.save(commit=False)
        task.save()
        return redirect('task-list')


class TaskDeleteView(LoginRequiredMixin, UserPassesTestMixin, DeleteView):
    model = Task
    template_name = 'tasks/task_confirm_delete.html'
    success_url = reverse_lazy('task-list')

    def test_func(self):
        # Проверяем, является ли пользователь членом группы "Project Manager"
        return self.request.user.groups.filter(name='Project Manager').exists()

