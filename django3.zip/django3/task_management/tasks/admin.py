# tasks/admin.py

from django.contrib import admin
from .models import Task

# Регистрируем модель Task в административной панели
admin.site.register(Task)
