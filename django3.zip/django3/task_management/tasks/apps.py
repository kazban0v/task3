from django.apps import AppConfig

# from .models import create_groups

class TasksConfig(AppConfig):
    name = 'tasks'

    def ready(self):
        pass
        # create_groups()

